export { default as feeds } from './feeds'
