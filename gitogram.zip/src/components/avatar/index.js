export { default as avatar } from './avatar.vue'
