export { default as feed } from './feed.vue'
