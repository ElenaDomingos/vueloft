<template>
<div class="c-topline">
  <div class="x-container">
    <div class="c-headline">

      <slot name="headline" />

    </div>
    <div class="content" v-if="$slots.content">
      <slot name="content" />
    </div>
  </div>
</div>
</template>

<style lang="scss" src="./topline.scss"></style>
