<template>
  <component :is="name"/>
</template>

<script>
import * as icons from './variants'

export default {
  name: 'Icon',
  components: { ...icons },
  porps: {
    name: {
      type: String,
      required: true,
      validator (value) {
        return Object.keys(icons).includes(value)
      }

    }
  }
}
</script>
<style src="./icon.scss" lang="scss" ></style>
