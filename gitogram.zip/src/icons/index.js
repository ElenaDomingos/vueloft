export { default as icon } from './icon.vue'
